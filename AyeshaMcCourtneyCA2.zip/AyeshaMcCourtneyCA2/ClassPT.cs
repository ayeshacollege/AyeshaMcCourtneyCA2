﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AyeshaMcCourtneyCA2
{
    internal class ClassPT : FormEmployee
    {
        public string? hours { get; set; }
        public string? hr;

        public ClassPT(string na, string ad, string cy, string ag, string phno, string em, string empl, string sp)
        {
            this.hours = hr;
        }


    }
}
